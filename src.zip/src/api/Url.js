// export const BASE_URL = 'http://10.1.6.68:31729/apiman-gateway/AnetaProvider/default/1.0?apikey=204824a8-b1a2-4d74-8383-7fdd7716d747';
export const BASE_URL = 'https://api.aneta.id/apiman-gateway/AnetaProvider/default/1.0?apikey=204824a8-b1a2-4d74-8383-7fdd7716d747'
// export const BASE_URL = 'http://103.234.195.147/flowable-rest/service/runtime/process-instances' //flowable