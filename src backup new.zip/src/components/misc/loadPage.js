export const pageLoad = () => setTimeout(() =>{
    window.location.reload()
},600)