import React from "react";

export const RequiredTooltip = () => (
    <a className="text-danger" data-toggle="tooltip" data-placement="right" title="Required">*</a>
)